﻿Prismwall Studio for Windows
Version 0.1.0

Use the setup EXE for the simplest install. The MSI is included for managed Windows installs.

Generated from the current Prismwall Studio source build.
